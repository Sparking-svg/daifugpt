# DaiFuGPT

基于 SuperGPT Connect v0.1.6 的独立衍生版，当前版本 0.1.9。默认中转站为 https://daifu.men。界面顶部、窗口标题、应用名称、Windows EXE、压缩包及默认站点统一显示 DaiFuGPT。图标采用透明背景的紫色渐变折带 D；字标采用用户提供的深色 DaiFu 与紫色 GPT，并提供深色主题变体。界面 PNG、Windows ICO 和 macOS ICNS 均由同一 SVG 生成。配置引擎沿用上游，未内置任何密钥。

保留原 LICENSE 和 licenses/ 全部第三方版权许可。上游来源：https://github.com/superpilot69/supergpt-connect/ 。这不是上游官方发布包，原项目测试记录不等于本衍生包的测试结果。

状态/恢复记录使用独立的 .daifugpt 目录，不迁移或读取原工具的备份。导入仍会按用户明确选择修改对应客户端配置，本次制作没有执行导入。
