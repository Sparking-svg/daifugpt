import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';

if (process.platform !== 'darwin') throw new Error('Build the macOS package on macOS.');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const version = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')).version;
const productName = JSON.parse(fs.readFileSync(path.join(root, 'src-tauri/tauri.conf.json'), 'utf8')).productName;
const target = 'aarch64-apple-darwin';
function run(command, args, options = {}) {
  const result = spawnSync(command, args, { cwd: root, stdio: 'inherit', ...options });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`${path.basename(command)} exited with ${result.status}`);
  return result.stdout;
}
run(process.execPath, [path.join(root, 'node_modules/@tauri-apps/cli/tauri.js'),
  'build', '--target', target, '--bundles', 'app', '--', '--locked']);

const source = path.join(root, 'src-tauri/target', target, `release/bundle/macos/${productName}.app`);
const plist = path.join(source, 'Contents/Info.plist');
const plistValue = key => run('/usr/libexec/PlistBuddy', ['-c', 'Print :'+key, plist], { encoding: 'utf8', stdio: 'pipe' }).trim();
if (plistValue('CFBundleName') !== productName) throw new Error('Incorrect macOS application name');
if (plistValue('CFBundleIdentifier') !== 'men.daifu.daifugpt') throw new Error('Incorrect macOS bundle identity');
const iconValue = plistValue('CFBundleIconFile');
const iconPath = path.join(source, 'Contents/Resources', iconValue.endsWith('.icns') ? iconValue : iconValue+'.icns');
const hash = data => createHash('sha256').update(data).digest('hex');
if (hash(fs.readFileSync(iconPath)) !== hash(fs.readFileSync(path.join(root,'src-tauri/icons/icon.icns')))) throw new Error('Incorrect macOS application icon');
const actual = run('/usr/libexec/PlistBuddy', ['-c', 'Print :CFBundleShortVersionString', path.join(source, 'Contents/Info.plist')],
  { encoding: 'utf8', stdio: 'pipe' }).trim();
if (actual !== version) throw new Error('App version does not match package.json');
const binary = fs.readFileSync(path.join(source, 'Contents/MacOS/daifugpt'));
if (binary.readUInt32LE(0) !== 0xfeedfacf || binary.readUInt32LE(4) !== 0x0100000c) {
  throw new Error('Expected an Apple Silicon executable');
}
const release = path.join(root, 'release');
fs.mkdirSync(release, { recursive: true });
const stage = fs.mkdtempSync(path.join(os.tmpdir(), 'daifugpt-macos-package-'));
try {
  const folder = path.join(stage, productName);
  fs.mkdirSync(folder);
  const app = path.join(folder, `${productName}.app`);
  run('/usr/bin/ditto', [source, app]);
  fs.copyFileSync(path.join(root, 'LICENSE'), path.join(app, 'Contents/Resources/LICENSE.txt'));
  fs.copyFileSync(path.join(root, 'LICENSE'), path.join(folder, 'LICENSE.txt'));
  fs.cpSync(path.join(root, 'licenses'), path.join(folder, 'licenses'), { recursive: true });
  run('/usr/bin/codesign', ['--force', '--deep', '--sign', '-', app]);
  run('/usr/bin/codesign', ['--verify', '--deep', '--strict', app]);
  fs.writeFileSync(path.join(folder, 'README.txt'), `${productName} ${version} · macOS Apple Silicon

解压后打开 ${productName}.app，也可拖入「应用程序」文件夹。
选择中转站 → 选择客户端 → 输入 API Key → 获取并勾选模型 → 导入。
导入后完全退出目标客户端，再重新打开并新建会话。
如需撤回，点右上角「恢复原配置」。

当前包使用 ad-hoc 签名，尚未完成 Apple Developer ID 签名及公证。
若系统拦截，请先确认下载自本项目的 GitHub Release，再按系统提示处理。

官网与使用说明：https://daifu.men/home#docs-connect
版本与下载：https://github.com/Sparking-svg/daifugpt/releases
验证记录：https://github.com/Sparking-svg/daifugpt/blob/main/VERIFICATION.md
`);
  const name = `${productName}-${version}-macOS-arm64.zip`;
  const archive = path.join(stage, name);
  run('/usr/bin/ditto', ['-c', '-k', '--norsrc', '--keepParent', folder, archive]);
  fs.copyFileSync(archive, path.join(release, name));
  fs.writeFileSync(path.join(release,'DaiFuGPT-macOS-verification.json'), JSON.stringify({productName,version,platform:process.platform,architecture:'arm64',bundle:productName+'.app',identifier:plistValue('CFBundleIdentifier'),adHocSignatureVerified:true,developerIDNotarized:false,iconSha256:hash(fs.readFileSync(iconPath)),executableSha256:hash(fs.readFileSync(path.join(app,'Contents/MacOS/daifugpt'))),archive:name,archiveSha256:hash(fs.readFileSync(archive)),archiveBytes:fs.statSync(archive).size,realClientIntegrationTested:false},null,2)+'\n');
  const hashes = fs.readdirSync(release).filter(name => name.endsWith('.zip')).sort()
    .map(name => `${createHash('sha256').update(fs.readFileSync(path.join(release, name))).digest('hex')}  ${name}`);
  fs.writeFileSync(path.join(release, 'SHA256SUMS.txt'), hashes.join('\n') + '\n');
  console.log(`Packaged: ${path.join(release, name)}`);
} finally {
  fs.rmSync(stage, { recursive: true, force: true });
}
